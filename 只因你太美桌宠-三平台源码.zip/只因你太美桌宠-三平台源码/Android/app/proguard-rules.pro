# No shrinking rules are required for this small native Android application.
